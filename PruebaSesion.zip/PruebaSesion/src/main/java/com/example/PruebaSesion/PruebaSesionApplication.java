package com.example.PruebaSesion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaSesionApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaSesionApplication.class, args);
	}

}
