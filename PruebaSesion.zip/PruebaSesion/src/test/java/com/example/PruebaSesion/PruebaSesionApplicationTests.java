package com.example.PruebaSesion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaSesionApplicationTests {

	@Test
	void contextLoads() {
	}

}
